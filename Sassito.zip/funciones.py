import os
import requests
from dotenv import load_dotenv
import re
import logging

# Load environment variables from a .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Get Jira credentials from environment variables
JIRA_USERNAME = os.getenv("JIRA_USERNAME")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")

# OpenAI API parameters
openai_endpoint = "https://api.openai.com/v1/chat/completions"
openai_api_key = os.getenv("OPENAI_API_KEY")

template = """Assistant is a large language model trained by OpenAI.

Assistant is designed to be able to assist with a wide range of tasks, from answering simple questions to providing in-depth explanations and discussions on a wide range of topics. As a language model, Assistant is able to generate human-like text based on the input it receives, allowing it to engage in natural-sounding conversations and provide responses that are coherent and relevant to the topic at hand.

Assistant is constantly learning and improving, and its capabilities are constantly evolving. It is able to process and understand large amounts of text, and can use this knowledge to provide accurate and informative responses to a wide range of questions. Additionally, Assistant is able to generate its own text based on the input it receives, allowing it to engage in discussions and provide explanations and descriptions on a wide range of topics.

Overall, Assistant is a powerful tool that can help with a wide range of tasks and provide valuable insights and information on a wide range of topics. Whether you need help with a specific question or just want to have a conversation about a particular topic, Assistant is here to assist.

{history}
Human: {human_input}
Assistant:"""

# Function to create a Jira ticket
def create_jira_ticket(summary, description, issue_type, key):
    url = "https://say2eat.atlassian.net/rest/api/3/issue"
    payload = {
        "fields": {
            "project": {"key": "RSC"},
            "summary": summary,
            "description": {
                "type": "doc",
                "version": 1,
                "content": [
                    {
                        "type": "paragraph",
                        "content": [
                            {
                                "type": "text",
                                "text": description
                            }
                        ]
                    }
                ]
            },
            "issuetype": {"name": issue_type},
            "priority": {"name": "Medium"}
        }
    }

    # Set custom fields based on the key
    if key == "test order":
        payload["fields"].update({
            "customfield_10179": {"value": "Investigation"},
            "customfield_10153": {"value": "Ordering"},
            "customfield_10155": {"value": "Level 1 - Product Features"},
            "customfield_10182": {"value": "Resolved by T2"},
            "customfield_10156": {"value": "Yes"},
            "priority": {"name": "Medium"}
        })
    elif key == "close restaurant":
        payload["fields"].update({
            "customfield_10179": {"value": "Back Office"},
            "customfield_10153": {"value": "Store Configuration"},
            "customfield_10155": {"value": "Level 2 - Admin (Internal Tools)"},
            "customfield_10182": {"value": "Resolved by T2"},
            "customfield_10156": {"value": "Yes"},
            "priority": {"name": "Medium"}
        })
    elif key == "open insights":
        payload["fields"].update({
            "customfield_10179": {"value": "Back Office"},
            "customfield_10153": {"value": "Store Configuration"},
            "customfield_10155": {"value": "Level 3 - Dev Tools"},
            "customfield_10182": {"value": "Resolved by T2"},
            "customfield_10156": {"value": "Yes"},
            "priority": {"name": "Medium"}
        })
    elif key == "clarity check":
        payload["fields"].update({
            "customfield_10179": {"value": "Dispatch Investigation"},
            "customfield_10153": {"value": "Delivery"},
            "customfield_10155": {"value": "Level 1 - Product Features"},
            "customfield_10182": {"value": "Resolved by T2"},
            "customfield_10156": {"value": "Yes"},
            "priority": {"name": "Low"}
        })
    elif key == "delivery range":
        payload["fields"].update({
            "customfield_10179": {"value": "Back Office"},
            "customfield_10153": {"value": "Store Configuration"},
            "customfield_10155": {"value": "Level 2 - Admin (Internal Tools)"},
            "customfield_10182": {"value": "Resolved by T2"},
            "customfield_10156": {"value": "Yes"},
            "priority": {"name": "Low"}
        })

    headers = {
        "Content-Type": "application/json"
    }

    response = requests.post(url, json=payload, auth=(JIRA_USERNAME, JIRA_API_TOKEN), headers=headers)
    if response.status_code == 201:
        response_json = response.json()
        issue_key = response_json.get("key")
        issue_url = f"https://say2eat.atlassian.net/browse/{issue_key}"
        return issue_url
    else:
        logger.error(f"Error creating ticket: {response.status_code} - {response.text}")
        return None

# Function to generate a response from OpenAI API
def generate_openai_response(input_text):
    messages = [
        {"role": "system", "content": template.format(history="", human_input=input_text)},
        {"role": "user", "content": input_text}
    ]

    data = {
        "model": "gpt-3.5-turbo",
        "messages": messages,
        "max_tokens": 150,
        "temperature": 0.7,
        "top_p": 1,
        "n": 1,
        "stop": ["\n"]
    }

    headers = {
        "Authorization": f"Bearer {openai_api_key}",
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(openai_endpoint, json=data, headers=headers)
        response.raise_for_status()
        response_json = response.json()
        return response_json["choices"][0]["message"]["content"].strip()
    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred: {http_err}")
        logger.error(f"Response content: {response.content}")
        return "I'm sorry, I couldn't generate a response at this time."
    except Exception as err:
        logger.error(f"Other error occurred: {err}")
        return "I'm sorry, I couldn't generate a response at this time."

# Function to process Slack messages
def process_slack_message(message):
    logger.debug(f"Processing message: {message}")

    patterns = {
        "test order": r'(?i)create a test order ticket for (.+)',
        "close restaurant": r'(?i)create a close restaurant ticket for (.+)',
        "open insights": r'(?i)create an open insights ticket for (.+)',
        "clarity check": r'(?i)create a clarity check ticket for (.+)',
        "delivery range": r'(?i)create a delivery range ticket for (.+)'
    }


    for key, pattern in patterns.items():
        match = re.search(pattern, message)
        if match:
            restaurant_name = match.group(1)
            if key == "test order":
                summary = f"[Ordering] - Test Order for {restaurant_name}"
                description = f"This is a ticket created by Sassito to inform that a test order was performed for: {restaurant_name}."
                logger.debug(f"Match found for test order: {restaurant_name}")
                issue_type = "Task"
            elif key == "close restaurant":
                summary = f"[StoreSettings] - Close {restaurant_name} from Admin"
                description = f"This is a ticket informing the closing of the restaurant: {restaurant_name}, created automatically by Sassito."
                logger.debug(f"Match found for close restaurant: {restaurant_name}")
                issue_type = "Task"
            elif key == "open insights":
                summary = f"[Dashboard] - Open Insights for {restaurant_name}"
                description = f"This is a ticket to inform that we Open Insights for the restaurant: {restaurant_name}, created automatically by Sassito."
                logger.debug(f"Match found for open insights: {restaurant_name}")
                issue_type = "Task"
            elif key == "clarity check":
                summary = f"[Delivery] - Clarity Check for {restaurant_name}"
                description = f"This is a ticket to inform that a clarity check for the restaurant: {restaurant_name}, was done and created automatically by Sassito."
                logger.debug(f"Match found for clarity check: {restaurant_name}")
                issue_type = "Task"
            elif key == "delivery range":
                summary = f"[StoreSettings] - Information about delivery range of {restaurant_name}"
                description = f"This is a ticket to inform that we provide information about the delivery range of the restaurant: {restaurant_name}, created automatically by Sassito."
                logger.debug(f"Match found for delivery range: {restaurant_name}")
                issue_type = "Task"
            
            issue_url = create_jira_ticket(summary, description, issue_type, key)
            if issue_url:
                return f"The ticket has been created in Jira. You can access the ticket here: {issue_url}"
            else:
                return "An error occurred while creating the ticket in Jira."
    
    # If no patterns match, use OpenAI to generate a response
    return generate_openai_response(message)

# Test the function
if __name__ == "__main__":
    test_message = "Hello @Sassito Slack Bot, can you create a test order ticket for Restaurant Example?"
    response = process_slack_message(test_message)
    print(response)

