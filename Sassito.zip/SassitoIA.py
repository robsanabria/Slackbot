import os
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from dotenv import load_dotenv
from funciones import process_slack_message  # Importa la función desde funciones.py

# Load environment variables from the .env file
load_dotenv('.env')

# Initialize the app with your bot token and socket mode handler
app = App(token=os.environ.get("SLACK_BOT_TOKEN"))

# Handler for app mentions
@app.event("app_mention")
def handle_app_mention_events(body, say, logger):
    logger.info("App mention event received: %s", body)
    try:
        user = body['event']['user']
        text = body['event']['text']
        thread_ts = body['event'].get('thread_ts', body['event']['ts'])
        logger.info("User: %s, Text: %s", user, text)

        # Check if the message is a greeting
        greetings = ["hi", "hello", "hola"]
        if any(greeting in text.lower() for greeting in greetings):
            say(f"<@{user}> Hello, how can I assist you?", thread_ts=thread_ts)
            return

        # Use the process_slack_message function to handle the message
        response = process_slack_message(text)
        # Replace "Assistant" with "Sassito" in the response
        response = response.replace("Assistant", "Sassito")
        say(f"<@{user}> {response}", thread_ts=thread_ts)
    except Exception as e:
        logger.error("Error handling app mention: %s", e)
        say("An error occurred while processing your request. Please try again later.", thread_ts=body['event']['ts'])

# Handler for message events
@app.event("message")
def handle_message_events(body, logger):
    logger.info("Message event received: %s", body)

# Start your app
if __name__ == "__main__":
    try:
        logger = app.logger
        logger.info("Starting the Slack bot...")
        SocketModeHandler(app, os.environ["SLACK_APP_TOKEN"]).start()
    except Exception as e:
        print(f"Error starting the app: {e}")